import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { useParams } from "react-router-dom";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../redux/hooks/hooks";
import { fetchCompanyThunk } from "../../../redux/slices/companySlice";

type Tab =
  | "overview"
  | "subscription"
  | "admins"
  | "billing"
  | "tickets";

/* ===============================================================
   HELPERS
================================================================ */

const formatLabel = (
  value: string | null | undefined,
) => {
  if (!value) return "-";

  return value
    .toLowerCase()
    .split("_")
    .map(
      (word) =>
        word.charAt(0).toUpperCase() + word.slice(1),
    )
    .join(" ");
};

/* ===============================================================
   COMPANY DETAILS
================================================================ */

const CompanyDetails = () => {
  const [activeTab, setActiveTab] =
    useState<Tab>("overview");

  const dispatch = useAppDispatch();

  const { companyId } = useParams();

  const {
    companyDetails,
    loading,
    error,
  } = useAppSelector(
    (state) => state.company,
  );

  useEffect(() => {
    if (companyId) {
      dispatch(fetchCompanyThunk(companyId));
    }
  }, [companyId, dispatch]);

  /* =========================================================
     TEMPORARY DATA
     Replace these with backend data later
  ========================================================= */

  const subscriptionStatus = "Active";
  const billingCycle = "Monthly";

  const adminName = "John Doe";
  const adminEmail = "john@abctech.com";
  const adminInitials = "JD";

  /* =========================================================
     LOADING
  ========================================================= */

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-gray-200 border-t-[#7C3AED]" />

          <p className="mt-3 text-sm text-gray-500">
            Loading company details...
          </p>
        </div>
      </div>
    );
  }

  /* =========================================================
     ERROR
  ========================================================= */

  if (error) {
    return (
      <div className="rounded-2xl border border-red-100 bg-red-50 p-6">
        <p className="text-sm text-red-600">
          {error}
        </p>
      </div>
    );
  }

  /* =========================================================
     COMPANY NOT FOUND
  ========================================================= */

  if (!companyDetails) {
    return (
      <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <p className="text-sm text-gray-500">
          Company details not found.
        </p>
      </div>
    );
  }

  const companyStatus = formatLabel(
    companyDetails.status,
  );

  const subscriptionName =
    formatLabel(
      companyDetails.subscriptionName,
    );

  return (
    <div className="space-y-6">

      {/* =====================================================
          COMPANY HEADER
      ====================================================== */}

      <div className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">

        {/* Top accent */}

        <div className="h-1 bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#A78BFA]" />

        <div className="p-6">

          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">

            {/* Company Logo + Details */}

            <div className="flex items-center gap-4">

              {/* Logo */}

              <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-br from-[#7C3AED] to-[#8B5CF6] text-xl font-bold text-white shadow-md shadow-purple-100">

                {companyDetails.logo ? (
                  <img
                    src={companyDetails.logo}
                    alt={companyDetails.companyName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span>
                    {companyDetails.companyName
                      ?.slice(0, 2)
                      .toUpperCase() ?? "CO"}
                  </span>
                )}

              </div>

              {/* Details */}

              <div>

                <div className="flex flex-wrap items-center gap-3">

                  <h1 className="text-2xl font-semibold tracking-tight text-gray-900">
                    {companyDetails.companyName}
                  </h1>

                  <StatusBadge
                    value={companyStatus}
                    type={
                      companyDetails.status === "ACTIVE"
                        ? "active"
                        : "expired"
                    }
                  />

                </div>

                <p className="mt-1 text-sm font-medium text-gray-500">
                  {formatLabel(
                    companyDetails.companyType,
                  )}
                </p>

                <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-sm text-gray-500">

                  <span>
                    {companyDetails.companyEmail}
                  </span>

                  <span>
                    {companyDetails.phone}
                  </span>

                  <span>
                    {companyDetails.website || "-"}
                  </span>

                </div>

              </div>

            </div>

            {/* Suspend Company */}

            <button
              type="button"
              className="w-full rounded-xl border border-red-200 bg-red-50 px-5 py-2.5 text-sm font-medium text-red-600 transition hover:border-red-300 hover:bg-red-100 lg:w-auto"
            >
              Suspend Company
            </button>

          </div>
        </div>
      </div>

      {/* =====================================================
          SUMMARY CARDS
      ====================================================== */}
{/* 
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">

        <SummaryCard
          title="Company Status"
          value={companyStatus}
          subtitle={
            companyDetails.status === "ACTIVE"
              ? "Company is currently active"
              : "Company is currently inactive"
          }
          icon="✓"
          iconType={
            companyDetails.status === "ACTIVE"
              ? "success"
              : "default"
          }
        />

        <SummaryCard
          title="Employees"
          value={companyDetails.numberOfEmployees}
          subtitle="Registered employee range"
          icon="◎"
          iconType="blue"
        />

        <SummaryCard
          title="Subscription"
          value={subscriptionName}
          subtitle="Current subscription plan"
          icon="◆"
          iconType="purple"
        />

      </div> */}

      {/* =====================================================
          TABS
      ====================================================== */}

      <div className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">

        {/* Tab Navigation */}

        <div className="overflow-x-auto">
          <div className="flex min-w-max border-b border-gray-100 px-4 sm:px-6">

            <TabButton
              label="Overview"
              active={activeTab === "overview"}
              onClick={() =>
                setActiveTab("overview")
              }
            />

            <TabButton
              label="Subscription"
              active={activeTab === "subscription"}
              onClick={() =>
                setActiveTab("subscription")
              }
            />

            <TabButton
              label="Company Admins"
              active={activeTab === "admins"}
              onClick={() =>
                setActiveTab("admins")
              }
            />

            <TabButton
              label="Billing History"
              active={activeTab === "billing"}
              onClick={() =>
                setActiveTab("billing")
              }
            />

            <TabButton
              label="Support Tickets"
              active={activeTab === "tickets"}
              onClick={() =>
                setActiveTab("tickets")
              }
            />

          </div>
        </div>

        {/* ===================================================
            OVERVIEW
        ==================================================== */}

        {activeTab === "overview" && (
          <div className="p-6">

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">

              {/* =================================================
                  LEFT BIG COMPANY INFORMATION CARD
              ================================================= */}

              <div className="xl:col-span-2">

                <InfoCard
                  title="Company Information"
                  subtitle="Basic company information and registered address"
                  accent="purple"
                >

                  <div className="grid grid-cols-1 gap-8 md:grid-cols-2">

                    {/* =========================================
                        COMPANY INFORMATION
                    ========================================== */}

                    <div className="space-y-4">

                      <InfoRow
                        label="Company Name"
                        value={
                          companyDetails.companyName
                        }
                      />

                      <InfoRow
                        label="Registration Number"
                        value={
                          companyDetails.registrationNumber
                        }
                      />

                      <InfoRow
                        label="Email"
                        value={
                          companyDetails.companyEmail
                        }
                      />

                      <InfoRow
                        label="Phone"
                        value={
                          companyDetails.phone
                        }
                      />

                      <InfoRow
                        label="Company Type"
                        value={formatLabel(
                          companyDetails.companyType,
                        )}
                      />

                      <InfoRow
                        label="Employees"
                        value={
                          companyDetails.numberOfEmployees
                        }
                      />

                      <InfoRow
                        label="Year Established"
                        value={
                          companyDetails.yearEstablished?.toString() ??
                          "-"
                        }
                      />

                      <InfoRow
                        label="Website"
                        value={
                          companyDetails.website ?? "-"
                        }
                      />

                      <InfoRow
                        label="Status"
                        value={companyStatus}
                        valueType={
                          companyDetails.status === "ACTIVE"
                            ? "success"
                            : "default"
                        }
                      />

                    </div>

                    {/* =========================================
                        LOCATION
                    ========================================== */}

                    <div className="space-y-4 border-gray-100 md:border-l md:pl-8">

                      <InfoRow
                        label="Address"
                        value={
                          companyDetails.location?.address ??
                          "-"
                        }
                      />

                      <InfoRow
                        label="City"
                        value={
                          companyDetails.location?.city ??
                          "-"
                        }
                      />

                      <InfoRow
                        label="State"
                        value={
                          companyDetails.location?.state ??
                          "-"
                        }
                      />

                      <InfoRow
                        label="Country"
                        value={
                          companyDetails.location?.country ??
                          "-"
                        }
                      />

                      <InfoRow
                        label="Postal Code"
                        value={
                          companyDetails.location?.postalCode ??
                          "-"
                        }
                      />

                    </div>

                  </div>

                </InfoCard>

              </div>

              {/* =================================================
                  RIGHT SIDE CARDS
              ================================================= */}

              <div className="space-y-6">

                {/* =============================================
                    SUBSCRIPTION SUMMARY
                ============================================== */}

                <InfoCard
                  title="Subscription Summary"
                  subtitle="Current subscription plan"
                  accent="purple"
                >

                  <div className="rounded-xl border border-purple-100 bg-purple-50/60 p-4">

                    <div className="flex items-center gap-3">

                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-[#7C3AED] shadow-sm">
                        ◆
                      </div>

                      <div>
                        <p className="text-xs font-medium text-gray-500">
                          Current Plan
                        </p>

                        <p className="mt-1 text-sm font-semibold text-gray-900">
                          {companyDetails.subscription.subscriptionName}
                        </p>
                      </div>

                    </div>

                  </div>

                  <div className="mt-4 space-y-4">

                    <InfoRow
                      label="Status"
                      value={
                        companyDetails.subscription.status
                      }
                      valueType="success"
                    />

                    <InfoRow
                      label="Billing Cycle"
                      value={
                     companyDetails.subscription.billingCycle
                      }
                    />

                  </div>

                  <button
                    type="button"
                    className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#7C3AED] px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#6D28D9]"
                  >
                    <span>
                      View Subscription
                    </span>

                    <span className="text-base">
                      →
                    </span>
                  </button>

                </InfoCard>

                {/* =============================================
                    COMPANY ADMIN
                ============================================== */}

                <InfoCard
                  title="Company Admin"
                  subtitle="Primary administrator"
                  accent="blue"
                >

                  <div className="rounded-xl border border-blue-100 bg-blue-50/60 p-4">

                    <div className="flex items-center gap-3">

                      {/* Avatar */}

                      <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white text-sm font-semibold text-blue-600 shadow-sm">
                        {adminInitials}
                      </div>

                      {/* Admin details */}

                      <div className="min-w-0">

                        <p className="truncate text-sm font-semibold text-gray-900">
                          {companyDetails.admin.name}
                        </p>

                        <p className="mt-1 truncate text-xs text-gray-500">
                          {companyDetails.admin.email}
                        </p>

                      </div>

                    </div>

                  </div>

                  <button
                    type="button"
                    className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-blue-200 bg-white px-4 py-2.5 text-sm font-medium text-blue-600 transition hover:bg-blue-50"
                  >
                    <span>
                      View Admin
                    </span>

                    <span className="text-base">
                      →
                    </span>
                  </button>

                </InfoCard>

              </div>

            </div>

            {/* =================================================
                COMPANY DESCRIPTION
            ================================================== */}

            <div className="mt-6">

              <InfoCard
                title="Company Description"
                subtitle="About this company"
                accent="purple"
              >

                <div className="rounded-xl bg-gray-50 p-5">

                  <p className="text-sm leading-7 text-gray-600">
                    {companyDetails.description ||
                      "No description available."}
                  </p>

                </div>

              </InfoCard>

            </div>

          </div>
        )}

        {/* ===================================================
            SUBSCRIPTION TAB
        ==================================================== */}

        {activeTab === "subscription" && (
          <div className="p-6">

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">

              <InfoCard
                title="Current Subscription"
                subtitle="Active subscription plan"
                accent="purple"
              >

                <InfoRow
                  label="Plan"
                  value={
                    subscriptionName
                  }
                />

                {/* Temporary */}

                <InfoRow
                  label="Status"
                  value="Active"
                  valueType="success"
                />

                {/* Temporary */}

                <InfoRow
                  label="Billing Cycle"
                  value="Monthly"
                />

                {/* Temporary */}

                <InfoRow
                  label="Price"
                  value="₹2,999"
                />

              </InfoCard>

              <InfoCard
                title="Billing Period"
                subtitle="Current subscription period"
                accent="blue"
              >

                {/* Temporary */}

                <InfoRow
                  label="Start Date"
                  value="01 Sep 2026"
                />

                <InfoRow
                  label="Renewal Date"
                  value="01 Oct 2026"
                />

                <InfoRow
                  label="Next Payment"
                  value="₹2,999"
                />

                <InfoRow
                  label="Payment Status"
                  value="Paid"
                  valueType="success"
                />

              </InfoCard>

              <InfoCard
                title="Plan Limits"
                subtitle="Current plan usage limits"
                accent="green"
              >

                {/* Temporary */}

                <InfoRow
                  label="Members"
                  value="48 / 200"
                />

                <InfoRow
                  label="Company Admins"
                  value="1 / 5"
                />

                <InfoRow
                  label="Departments"
                  value="8 / 20"
                />

                <InfoRow
                  label="Tickets"
                  value="Unlimited"
                />

              </InfoCard>

            </div>

          </div>
        )}

        {/* ===================================================
            COMPANY ADMINS TAB
        ==================================================== */}

        {activeTab === "admins" && (
          <div className="p-6">

            <div className="overflow-hidden rounded-xl border border-gray-100">

              <div className="overflow-x-auto">

                <table className="w-full min-w-[700px] text-left text-sm">

                  <thead className="bg-gray-50">

                    <tr>

                      <TableHeader>
                        Admin
                      </TableHeader>

                      <TableHeader>
                        Email
                      </TableHeader>

                      <TableHeader>
                        Role
                      </TableHeader>

                      <TableHeader>
                        Status
                      </TableHeader>

                      <TableHeader>
                        Last Login
                      </TableHeader>

                    </tr>

                  </thead>

                  <tbody className="divide-y divide-gray-100">

                    {/* Temporary Admin Data */}

                    <tr className="transition hover:bg-gray-50">

                      <td className="px-5 py-4">

                        <div className="flex items-center gap-3">

                          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-50 text-xs font-semibold text-blue-600">
                            {adminInitials}
                          </div>

                          <span className="font-medium text-gray-900">
                            {adminName}
                          </span>

                        </div>

                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        {adminEmail}
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        Company Admin
                      </td>

                      <td className="px-5 py-4">

                        <StatusBadge
                          value="ACTIVE"
                          type="active"
                        />

                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        Today, 10:42 AM
                      </td>

                    </tr>

                  </tbody>

                </table>

              </div>

            </div>

          </div>
        )}

        {/* ===================================================
            BILLING HISTORY TAB
        ==================================================== */}

        {activeTab === "billing" && (
          <div className="p-6">

            <div className="overflow-hidden rounded-xl border border-gray-100">

              <div className="overflow-x-auto">

                <table className="w-full min-w-[750px] text-left text-sm">

                  <thead className="bg-gray-50">

                    <tr>

                      <TableHeader>
                        Payment ID
                      </TableHeader>

                      <TableHeader>
                        Date
                      </TableHeader>

                      <TableHeader>
                        Plan
                      </TableHeader>

                      <TableHeader>
                        Amount
                      </TableHeader>

                      <TableHeader>
                        Method
                      </TableHeader>

                      <TableHeader>
                        Status
                      </TableHeader>

                    </tr>

                  </thead>

                  <tbody className="divide-y divide-gray-100">

                    {/* Temporary Payment Data */}

                    <tr className="transition hover:bg-gray-50">

                      <td className="px-5 py-4 font-medium text-gray-900">
                        PAY-2026-001
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        01 Sep 2026
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        {subscriptionName}
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        ₹2,999
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        Card
                      </td>

                      <td className="px-5 py-4">

                        <StatusBadge
                          value="SUCCESS"
                          type="active"
                        />

                      </td>

                    </tr>

                  </tbody>

                </table>

              </div>

            </div>

          </div>
        )}

        {/* ===================================================
            SUPPORT TICKETS TAB
        ==================================================== */}

        {activeTab === "tickets" && (
          <div className="p-6">

            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">

              <MiniStat
                title="Open Tickets"
                value="3"
              />

              <MiniStat
                title="Resolved Tickets"
                value="42"
              />

              <MiniStat
                title="Total Tickets"
                value="45"
              />

            </div>

            <div className="mt-6 overflow-hidden rounded-xl border border-gray-100">

              <div className="overflow-x-auto">

                <table className="w-full min-w-[700px] text-left text-sm">

                  <thead className="bg-gray-50">

                    <tr>

                      <TableHeader>
                        Ticket
                      </TableHeader>

                      <TableHeader>
                        Subject
                      </TableHeader>

                      <TableHeader>
                        Created
                      </TableHeader>

                      <TableHeader>
                        Status
                      </TableHeader>

                    </tr>

                  </thead>

                  <tbody className="divide-y divide-gray-100">

                    {/* Temporary Ticket Data */}

                    <tr className="transition hover:bg-gray-50">

                      <td className="px-5 py-4 font-medium text-gray-900">
                        TKT-2026-021
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        Unable to update company profile
                      </td>

                      <td className="px-5 py-4 text-gray-600">
                        28 Sep 2026
                      </td>

                      <td className="px-5 py-4">

                        <StatusBadge
                          value="OPEN"
                          type="warning"
                        />

                      </td>

                    </tr>

                  </tbody>

                </table>

              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};

/* ===============================================================
   INFO CARD
================================================================ */

interface InfoCardProps {
  title: string;
  subtitle: string;
  children: ReactNode;
  accent?: "purple" | "blue" | "green";
}

const InfoCard = ({
  title,
  subtitle,
  children,
  accent = "purple",
}: InfoCardProps) => {
  const accentClasses = {
    purple: "bg-[#7C3AED]",
    blue: "bg-blue-500",
    green: "bg-emerald-500",
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">

      <div
        className={`h-1 ${accentClasses[accent]}`}
      />

      <div className="p-6">

        <h2 className="text-base font-semibold text-gray-900">
          {title}
        </h2>

        <p className="mt-1 text-xs text-gray-400">
          {subtitle}
        </p>

        <div className="mt-5">
          {children}
        </div>

      </div>
    </div>
  );
};

/* ===============================================================
   INFO ROW
================================================================ */

interface InfoRowProps {
  label: string;
  value: string;
  valueType?: "default" | "success";
}

const InfoRow = ({
  label,
  value,
  valueType = "default",
}: InfoRowProps) => {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-gray-100 pb-3 last:border-0 last:pb-0">

      <span className="shrink-0 text-sm text-gray-500">
        {label}
      </span>

      {valueType === "success" ? (
        <StatusBadge
          value={value}
          type="active"
        />
      ) : (
        <span className="max-w-[65%] text-right text-sm font-medium text-gray-900">
          {value}
        </span>
      )}

    </div>
  );
};

/* ===============================================================
   TAB BUTTON
================================================================ */

interface TabButtonProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

const TabButton = ({
  label,
  active,
  onClick,
}: TabButtonProps) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative px-5 py-4 text-sm font-medium transition ${
        active
          ? "text-[#7C3AED]"
          : "text-gray-500 hover:text-gray-800"
      }`}
    >
      {label}

      {active && (
        <span className="absolute inset-x-5 bottom-0 h-0.5 rounded-full bg-[#7C3AED]" />
      )}
    </button>
  );
};

/* ===============================================================
   STATUS BADGE
================================================================ */

interface StatusBadgeProps {
  value: string;
  type: "active" | "expired" | "warning";
}

const StatusBadge = ({
  value,
  type,
}: StatusBadgeProps) => {
  const classes = {
    active:
      "bg-emerald-50 text-emerald-700 border border-emerald-100",
    expired:
      "bg-gray-100 text-gray-600 border border-gray-200",
    warning:
      "bg-amber-50 text-amber-700 border border-amber-100",
  };

  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${classes[type]}`}
    >
      {value}
    </span>
  );
};

/* ===============================================================
   TABLE HEADER
================================================================ */

const TableHeader = ({
  children,
}: {
  children: ReactNode;
}) => {
  return (
    <th className="px-5 py-3 text-xs font-medium uppercase tracking-wide text-gray-500">
      {children}
    </th>
  );
};

/* ===============================================================
   MINI STAT
================================================================ */

const MiniStat = ({
  title,
  value,
}: {
  title: string;
  value: string;
}) => {
  return (
    <div className="rounded-xl border border-gray-100 bg-gray-50 p-5 transition hover:bg-gray-100/70">

      <p className="text-sm text-gray-500">
        {title}
      </p>

      <p className="mt-2 text-2xl font-semibold tracking-tight text-gray-900">
        {value}
      </p>

    </div>
  );
};

export default CompanyDetails;