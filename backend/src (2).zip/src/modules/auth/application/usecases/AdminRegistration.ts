import { HttpStatusCode } from "../../../../shared/constants/httpStattusCode";
import { MESSAGES } from "../../../../shared/constants/messages";
import { AppErrors } from "../../../../shared/errors/AppErrors";
import { IAccountRepository } from "../../domain/repositories/IAccountRepository";
import { IAdminRegistration } from "../abstractions/IAdminRegistration";
import { AdminRegistrationRequestDto } from "../dto/AdminregistrationRequestDto";


export class AdminRegistration implements IAdminRegistration {
  constructor(private readonly _accountRepository: IAccountRepository) {}

  async execute(dto: AdminRegistrationRequestDto) {
    const account = await this._accountRepository.findByEmail(dto.email);

    if (!account) {
      throw new AppErrors(
        MESSAGES.ACCOUNT_NOT_FOUND,
        HttpStatusCode.BAD_REQUEST,
      );
    }
 const existingAccount =
      await this._accountRepository.findByPhone(
        dto.phoneNumber,
      );
        if (
      existingAccount &&
      existingAccount.id !== account.id
    ) {
      throw new AppErrors(
        MESSAGES.PHONE_ALREADY_EXISTS,
        HttpStatusCode.CONFLICT,
      );
    }
    await this._accountRepository.updateAdminDetails(
      account.id,
      dto.firstName,
      dto.lastName,
      dto.phoneNumber,
      dto.designation,
    );

    return {
      accountId: account.id,
    };
  }
}
