import { Router } from "express";
import { companyController } from "../../container/container";
import { authMiddleware } from "../../../auth/container/container";
import { COMAPANY_ROUTES } from "../../../../shared/constants/route";

 const router = Router();
router.use(
  authMiddleware.authenticate.bind(authMiddleware)
);
router.get(
  COMAPANY_ROUTES.GET_ALL,
  
  async (req, res) => {
    await companyController.getAllCompanies(req,res);
  }
);
router.get(
  COMAPANY_ROUTES.GET_BY_ID,
  
  async (req, res) => {
    console.log("paased Id")
    await companyController.GetCompany(req,res);
  }
);
export default router;