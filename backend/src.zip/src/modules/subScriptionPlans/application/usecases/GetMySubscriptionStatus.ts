import { ICompanyRepository } from "../../../company/domain/repositories/ICompanyRepository";

import { ISubscriptionRepository } from "../../domain/repositories/ISubscriptionRepository";

import { Subscription } from "../../domain/entities/Subscription";
import { IGetMySubscriptionStatus } from "../abstraction/IGetmySubscriptionStatus";


export class GetMySubscriptionStatus
  implements IGetMySubscriptionStatus
{
  constructor(
    private readonly companyRepository: ICompanyRepository,

    private readonly subscriptionRepository:
      ISubscriptionRepository,
  ) {}

  async execute(
    accountId: string
  ): Promise<Subscription | null> {


    const company =
      await this.companyRepository.findByAccountId(
        accountId
      );

    if (!company) {
      return null;
    }

  
    return await this.subscriptionRepository.findByCompanyId(
      company.id
    );
  }
}