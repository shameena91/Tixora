import { Request, Response } from "express";

import { HttpStatusCode } from "../../../../shared/constants/httpStattusCode";
import { MESSAGES } from "../../../../shared/constants/messages";

import { ICreateTimeline } from "../../application/abstraction/ICreateTimeline";
import { IGetTimeline } from "../../application/abstraction/IGetTimeline";

import {
  TimelineCreateData,
} from "../../application/mappers/TimelineMapper";

import {
  TimelineEntityType,
} from "../../domain/entities/Timeline";

export class TimelineController {
  constructor(

    private readonly getTimeline: IGetTimeline
  ) {}

 
  // ------------------------------------
  // Get Timeline By Entity
  // ------------------------------------
  async getTimelineByEntity(
      req: Request<{ 
    id: string;}>,
    res: Response
  ): Promise<void> {
   
    const { id } = req.params;
    console.log("hhhhhhhhhhhhhhhhhhh")
    console.log(id)
    //  if (typeof entityId !== "string") {
    //       res.status(HttpStatusCode.BAD_REQUEST).json({
    //         success: false,
    //         message: MESSAGES.INVALID_COMPANY_REQUEST_ID,
    //       });
    //       return;
    //     }

    // if (!entityType || !entityId) {
    //   res.status(HttpStatusCode.BAD_REQUEST).json({
    //     success: false,
    //     message: "Entity type and entity ID are required",
    //   });

    //   return;
    // }

    // const isValidEntityType =
    //   Object.values(TimelineEntityType).includes(
    //     entityType as TimelineEntityType
    //   );

    // if (!isValidEntityType) {
    //   res.status(HttpStatusCode.BAD_REQUEST).json({
    //     success: false,
    //     message: "Invalid entity type",
    //   });

    //   return;
    // }

    const timeline =
      await this.getTimeline.execute(
         TimelineEntityType.COMPANY_REQUEST,
        id
      );

    res.status(HttpStatusCode.OK).json({
      success: true,
      data: timeline,
    });
  }
}